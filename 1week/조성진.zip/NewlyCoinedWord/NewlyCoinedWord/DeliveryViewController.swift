//
//  DeliveryViewController.swift
//  NewlyCoinedWord
//
//  Created by Alex Cho on 2023/07/22.
//

import UIKit

class DeliveryViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    


}
