//
//  ViewModel.swift
//  practiceTest
//
//  Created by Alex Cho on 2023/09/26.
//

import Foundation

class ViewModel{
    var myBool = false
    
    func toggleMyBool(){
        myBool.toggle()
    }
}
