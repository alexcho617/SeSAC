//
//  practiceTestTests.swift
//  practiceTestTests
//
//  Created by Alex Cho on 2023/09/26.
//

import XCTest
@testable import practiceTest

final class practiceTestTests: XCTestCase {
    var sut: ViewModel!
    override func setUpWithError() throws {
        try super.setUpWithError()
        sut = ViewModel()
    }

    override func tearDownWithError() throws {
        try super.tearDownWithError()
        sut = nil
    }

    func test_Toggle() throws {
        //given
        sut.myBool = false
        //when
        print("Hi")
        sut.toggleMyBool() //toggle timerState
        //then
        XCTAssert(sut.myBool == true, "")
    }

//    func testPerformanceExample() throws {
//        // This is an example of a performance test case.
//        self.measure {
//            // Put the code you want to measure the time of here.
//        }
//    }

}
