//
//  RxViewController.swift
//  SeSACRxSwiftBasicXcode14
//
//  Created by jack on 2023/10/23.
//

import UIKit
import 

class RxViewController: UIViewController {
    
    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var changeButton: UIButton!
    var nickname = Observable.just("고래밥")
    
    @IBOutlet var timerLabel: UILabel!
    
    var disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        nickname
            .subscribe { value in
                self.nameLabel.text = value
            } onError: { error in
                print("nickname - onError")
            } onCompleted: {
                print("nickname - onCompleted")
            } onDisposed: {
                print("nickname - Disposed")
            }
            .disposed(by: disposeBag)
 
        changeButton.rx.tap
            .subscribe { value in
                print("버튼 클릭 \(value)")
            } onError: { error in
                print("changeButton - onError")
            } onCompleted: {
                print("changeButton - onCompleted")
            } onDisposed: {
                print("changeButton - Disposed")
            }
            .disposed(by: disposeBag)
        
//        Observable<Int>.interval(.seconds(1), scheduler: MainScheduler.instance)
//            .subscribe { value in
//                print("value")
//                self.timerLabel.text = "\(value)"
//            } onError: { error in
//                print("interval - \(error)")
//            } onCompleted: {
//                print("interval completed")
//            } onDisposed: {
//                print("interval disposed")
//            }
//            .disposed(by: disposeBag)
    }
}
