//
//  APIManager.swift
//  RxSwiftWithSingle
//
//  Created by jack on 2023/11/24.
//

import UIKit
import RxSwift
import Alamofire

enum JackError {
    case jackError
}

final class Network {
    
    static let baseUrl = "https://v2.jokeapi.dev/joke/Programming?type=single"
    
    static func fetchJoke() -> Observable<Joke> {
        return Observable.create { observer -> Disposable in
            AF.request(URL(string: baseUrl)!)
                .validate()
                .responseDecodable(of: Joke.self) { response in
                    switch response.result {
                    case .success(let success):
                        observer.onNext(success)
                        observer.onCompleted()
                    case .failure(let failure):
                        observer.onError(failure)
                    }
                }
            return Disposables.create()
        }
    }
    
 
}
